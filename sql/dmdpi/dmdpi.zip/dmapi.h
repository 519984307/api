#ifndef DMAPI_H
#define DMAPI_H
#ifdef DM_DPI_WIN32
#include "./include/DPItypes.h"
#include "dmquery.h"
#include "dmdatabase.h"
#include "dmvalueobject.h"

#endif
#endif // DMAPI_H
